<?php /* Template Name: googleMapsTemplate */
get_header();
?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">
		
		<?php
		if ( have_posts() ) {

			// Load posts loop.
			while ( have_posts() ) {
				the_post();
				get_template_part( 'template-parts/content/content' );
			}

			// Previous/next page navigation.
			twentynineteen_the_posts_navigation();

		} else {

			// If no content, include the "No posts found" template.
			get_template_part( 'template-parts/content/content', 'none' );

		}
		?>
		
<?php
require_once 'databaseconnect.php';
        
$jsondata = "https://discover.search.hereapi.com/v1/discover?at=42.69751,23.32415&q=bank&limit=50&apiKey=iSooBtsSDS2AuZFbXYjM7m66YCBWr75vl2EJJtKFwVA";
 
$jsonstring = file_get_contents($jsondata);
$phpdata = json_decode($jsonstring,true);
for($x = 0 ; $x<count($phpdata["items"]);$x++) {
$sql = "INSERT INTO markersAPI (name,lat,lng,address,type,phone,website) VALUES ('" . $phpdata["items"][$x]["title"] . "', '" . $phpdata["items"][$x]["position"]["lat"] . "', '" . $phpdata["items"][$x]["position"]["lng"] . "', '" . $phpdata["items"][$x]["address"]["label"] . "', '" . $phpdata["items"][$x]["categories"][0]["name"] . "', '" . $phpdata["items"][$x]["contacts"][0]["phone"][0]["value"] . "', '" . $phpdata["items"][$x]["contacts"][0]["www"][0]["value"] . "')";

if ($conn->query($sql) === TRUE) {
} else {
}
}


$sql = "SELECT id,lat,lng,name,address FROM markersAPI";
$result = $conn->query($sql);
$result2 = $conn->query($sql);
?>
<!DOCTYPE html">
<head>
<title> Google Map With Markers :) </title>
</head>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB-r3McY0OcdCLDhfRGThefNzvw0b4Wu58"></script>


<script>

function initMap() {
   latLong = new google.maps.LatLng(47.0303105, 28.815481);
     map = new google.maps.Map(document.getElementById('mapCanvas'), {
         center: latLong,
         mapTypeId: google.maps.MapTypeId.ROADMAP,
         zoom: 14
     });
            console.log("Map is ready.")
    
    var markers = [
        <?php if($result->num_rows >0){
            while($row = $result->fetch_assoc()){
                echo '["'.$row['name'].'", '.$row['lat'].', '.$row['lng'].'],';;
                }
        }
        ?>
    ];

                          
    
    var infoWindowContent = [
        <?php if($result2->num_rows > 0){
            while($row = $result2->fetch_assoc()){ ?>
                ['<div class="info_content">' +
                '<h3><?php echo $row['name']; ?></h3>' +
                '<p><?php echo $row['address']; ?></p>' + '</div>'],
        <?php }
        }
        ?>
    ];
    
    var bounds = new google.maps.LatLngBounds();
    var infoWindow = new google.maps.InfoWindow(), marker, i;

    for( i = 0; i < markers.length; i++ ) {
        var position = new google.maps.LatLng(markers[i][1], markers[i][2]);
        marker = new google.maps.Marker({
            position: position,
            map: map,
            title: markers[i][0]
        });
        bounds.extend(marker.position);

         google.maps.event.addListener(marker, 'click', (function(marker, i) {
            return function() {
                infoWindow.setContent(infoWindowContent[i][0]);
                infoWindow.open(map, marker);
            }
        })(marker, i));
        
      }
     map.fitBounds(bounds);
 }
 
 google.maps.event.addDomListener(window, 'load', initMap);
 </script>


<style type="text/css">
#mapCanvas {
    width: 70%;
    height: 500px;
    margin: auto;
}
</style>
</head>
<body>

<div id="mapContainer">
    <div id="mapCanvas"></div>
</div>
</body>
</html>

		</main><!-- .site-main -->
	</div><!-- .content-area -->

<?php
get_footer();
